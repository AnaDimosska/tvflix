# Contributing to **TvMaze**

* *Issues* - If you have a question, or you think you've discovered an issue, then find/file an issue BEFORE starting work to fix/implement it.
* *Enhancement* - If you want to contribute to the repository, go ahead, any kind of patches are encouraged, and may be submitted by forking this project and submitting a pull request. If you have something big in mind, or any architectural change, please raise an issue first to discuss it.

👍🎉🚀Please note that any piece of contribution will be cherished and TvMaze will love to have it. At the end, it is all about helping the Android Community to thrive for better development👍🎉🚀
