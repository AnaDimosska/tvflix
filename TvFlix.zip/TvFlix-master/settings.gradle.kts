include(":app")
rootProject.name = "TvFlix"
