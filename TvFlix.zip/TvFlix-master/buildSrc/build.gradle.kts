repositories {
    jcenter()
}

plugins {
    `kotlin-dsl`
    `java-gradle-plugin`
}

kotlinDslPluginOptions {
    experimentalWarning.set(false)
}
